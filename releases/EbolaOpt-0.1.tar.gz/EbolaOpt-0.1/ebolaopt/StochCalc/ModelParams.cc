#include "ModelParams.h"
 
ModelParams::ModelParams() { 
  beta_I = beta_H = beta_F = alpha = gamma_h = 0;
  theta_1 = delta_1 = delta_2 = gamma_f = gamma_i = gamma_d = 0;
}
 
ModelParams::~ModelParams() { }
